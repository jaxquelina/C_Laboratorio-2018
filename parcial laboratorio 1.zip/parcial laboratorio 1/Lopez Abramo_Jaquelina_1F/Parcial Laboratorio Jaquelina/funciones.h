#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

/**PARCIAL: UNA EMPRESA NECESITA ADMINISTRAR EL STOCK DE SUS PRODUCTOS:
PRODUCTO:CODIGO
         DESCRIPCION
         IMPORTE
         CANTIDAD*/

struct Eproducto{
               int codigo;
               char descripcion [100];
               float importe;
               int cantidad;
               int estaLibre;

               };



struct Eprovedor{

                 int codigo;
                 char descripcion[100];
                 int estado;

                 };

/** \brief La fancion Menu contendra el menu con las opciones para el usuario.
 *
 * \return esta funcion retornara un entero que sera la opcion que el usuario mingrese.
 */
int menu();



/** \brief Esta funcion se encargara de inicializar cuando se ingrese una persona.
 *
 * \param gente[] La estructura persona.
 * \param int cantidad La cantidad de personas que se podran ingresar.
 * \return sera void es decir no devolvera nada.
 *
 */
void inicializarProductos(struct Eproducto producto[],int cantidad);



/** \brief Mostrara a una persona sola me servira para usar en otras funciones
 *
 * \param gente[] La estructura persona.
 * \return void
 *
 */
void mostrarProducto(struct Eproducto producto);



/** \brief esta funcion me indicara si habra espacio para seguir agregando personas o no
 *
 * \param gente[] La estructura persona.
 * \param int cantidad La cantidad de personas que se podran ingresar.
 * \return int retornara -1 en caso de que no alla mas espacio discponible
 *
 */
int buscarLibre(struct Eproducto producto[], int cantidad);


/** \brief Esta funcion me permitira buscar a una persona por medio del DNI que sea el dato unico
           de cada persona.
 *  \param gente[] La estructura persona.
 * \param int cantidad La cantidad de personas que se podran ingresar.
 * \param DNI int
 * \return int Si el DNI  ya fue ingresado por otro usuario devolvera -1.
 *
 */
int buscarProducto(struct Eproducto producto[], int cantidad, int codigo);


/** \brief Esta funcion me permitira ingresar nuevas personas siempre y cuando alla espacio y el documento
           no este repetido.
 *
* \param gente[] La estructura persona.
 * \param int cantidad La cantidad de personas que se podran ingresar.
 * \return void es decir no retornara nada.
 *
 */
void altaProducto(struct Eproducto producto[], int cantidad);


/** \brief Esta funcion me permitira borrar del programa las personas que se ingresen.
 *
* \param gente[] La estructura persona.
 * \param int cantidad La cantidad de personas que se podran ingresar.
 * \return void es decir no retornara nada.
 *
 */
void bajaProducto(struct Eproducto producto[], int cantidad);


/** \brief Sera el menu a mostrar  la cual sera llamada por la funcion modificacion
 *
 * \return int
 *
 */
int menuModificacion();



/** \brief Sera la encargada de realizar la modificacion de los productos
 *
 * \param producto[] struct Eproducto
 * \param cantidad int
 * \return void
 *
 */
void modificar(struct Eproducto producto[],int cantidad);



/** \brief Esta funcion me permitira ordenar a las personas ingresadas por su nombre.
 *
* \param gente[] La estructura persona.
 * \param int cantidad La cantidad de personas que se podran ingresar.
 * \return void es decir no retornara nada.
 *
 */







#endif // FUNCIONES_H_INCLUDED

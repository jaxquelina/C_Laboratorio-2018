#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "funciones.h"

int menu()
{
    int opcion;

    system("cls");
    system("color F0");
    printf("---Bienvenido al programa para cargar Productos ---\n\n");
    printf("1-Alta\n");
    printf("2-Modificacion\n");
    printf("3-Baja\n");
    printf("4-Informar\n");
    printf("5-Listar\n");
    printf("6-Mostrar Proveedores\n");
    printf("7-Salir\n");
    printf("\nIndique opcion para comenzar: ");
    scanf("%d", &opcion);



    return opcion;
}




void inicializarProductos(struct Eproducto producto[],int cantidad)
{
    int i;

    for(i=0;i<cantidad;i++)
    {
        producto[i].estaLibre=1;

    }
}



void mostrarProducto(struct Eproducto producto)

{
    printf("  %d     %s     %f  %d ", producto.codigo, producto.descripcion,producto.importe, producto.cantidad);
}



int buscarLibre(struct Eproducto producto[], int cantidad)
{
    int indice = -1;
    int i;

    for(i=0; i <cantidad; i++)
    {
        if(producto[i].estaLibre== 1)
        {
            indice = i;
            break;
        }
    }
    return indice;
}



int buscarProducto(struct Eproducto producto[], int cantidad, int codigo)
{
    int indice = -1;
    int i;

    for(i=0; i < cantidad; i++)
    {
        if(producto[i].estaLibre == 0 && producto[i].codigo == codigo)
        {
            indice = i;
            break;
        }
    }
    return indice;
}




void altaProducto(struct Eproducto producto[], int cantidad)
{

    struct Eproducto nuevoProducto;
    int indice;
    int esta;
    int codigo;
    char codigoAuxStr[50];
    char descripcionAuxStr[100];
    char importeAuxStr[50];
    char cantidadAuxStr[50];

    system("cls");
    printf("---Alta Producto--\n\n");

    indice = buscarLibre(producto, cantidad);

    if(indice == -1)
    {
        printf("\nEl sistema esta completo. No se puede dar de alta nuevos productos.\n\n");
    }
    else
    {
       if ((!getStringNumeros("Ingrese el Codigo: ",codigoAuxStr)) || (strlen(codigoAuxStr)>5)

)      {

            printf ("El Codigo debe ser numerico y menor a 5 caracteres\n");

                while((!getStringNumeros("Reingrese el CODIGO: ",codigoAuxStr)) || (strlen(codigoAuxStr)>5))
                  {
                      printf("NO INGRESE LETRAS ");

                  }


       }



        codigo = atoi(codigoAuxStr);

        esta = buscarProducto(producto,cantidad,codigo);

        if(esta != -1)
        {
            printf("\nEl codigo %d ya esta dado de alta en el sistema\n", codigo);
                   mostrarProducto(producto[esta]);

        }
        else{
                   nuevoProducto.estaLibre = 0;
                   nuevoProducto.codigo = codigo;


                if (!getStringLetras("Ingrese la descripcion: ",descripcionAuxStr))
                 {
                  printf ("La descripcion deben ser letras \n");

                 while(!getStringLetras("Reingrese la descripcion ",descripcionAuxStr))
                  {
                      printf("NO INGRESE NUMEROS ");

                  }

                  }

                   strcpy(nuevoProducto.descripcion,(strlwr(descripcionAuxStr)));



                if (!getStringNumerosFlotantes("Ingrese el importe: ",importeAuxStr))
             {
                while(!getStringNumerosFlotantes("Reingrese importe: ",importeAuxStr))
                  {
                      printf("NO INGRESE LETRAS ");

                  }
             }

                nuevoProducto.importe = atof(importeAuxStr);



                   if (!getStringNumeros("Ingrese cantidad: ",cantidadAuxStr))
             {
                while(!getStringNumeros("Reingrese cantidad: ",cantidadAuxStr))
                  {
                      printf("NO INGRESE LETRAS ");

                  }
             }

                nuevoProducto.cantidad = atoi(cantidadAuxStr);

             while(nuevoProducto.cantidad <0)
             {
                 printf("POR FAVOR LA CANTIDAD DEBE SER MAYOR A 0: ");
                 scanf("%d",&nuevoProducto.cantidad);
             }


                   producto[indice] = nuevoProducto;

                   printf("\nAlta exitosa!!!\n\n");

           }

  }

}

void bajaProducto(struct Eproducto producto[], int cantidad){
int  codigo;
int esta;
char confirma;

system("cls");
printf("---Baja Persona---\n\n");

   printf("Ingrese CODIGO: ");
        scanf("%d", &codigo);

        esta = buscarProducto(producto, cantidad, codigo);

        if(esta == -1)
        {
            printf("\nEl codigo  no se encuentra en el sistema\n\n");

        }
        else{

                mostrarProducto(producto[esta]);

        do{
            printf("\nConfirma baja? [s|n]: ");
            fflush(stdin);
            scanf("%c", &confirma);
            confirma = tolower(confirma);
        }while(confirma != 's' && confirma != 'n');

        if(confirma == 's'){
            producto[esta].estaLibre = 1;
            printf("\nSe ha realizado la baja\n\n");
        }
        else{
            printf("\nSe ha cancelado la baja\n\n");
        }

        }
}




void ordenarProductos(struct Eproducto producto[], int cantidad)
{
int i;
int j;
struct Eproducto productoAux;

                for(i=0; i < cantidad - 1; i++)
                {
                    if(producto[i].estaLibre == 1)
                    {
                        continue;
                    }
                    for(j=i+1; j < cantidad; j++)
                    {
                        if(producto[i].estaLibre == 1)
                        {
                            continue;
                        }
                    if(producto[i].importe < producto[j].importe)
                {
                    productoAux = producto[j];
                    producto[j] = producto[i];
                    producto[i] = productoAux;
                }

                else if(producto[i].importe==producto[j].importe)
            {
                if(strcmp(producto[i].descripcion, producto[j].descripcion)>0)
            {
                productoAux = producto[i];
                producto[i] = producto[j];
                producto[j] = productoAux;
            }
            }
                    }
                }
                printf("Precio\t\t\tDescripcion\t\t\tCodigo\t\t\tCantidad\n");

       for(i=0; i<cantidad; i++)
    {
        if(producto[i].estaLibre==0)
        {
            printf("\n%f\t\t\t%s\t\t\t%d\t\t\t%d\n",producto[i].importe, producto[i].descripcion, producto[i].codigo , producto[i].cantidad);
        }



}
}


int menuModificacion(){
    int opcion;
    system("cls");
    system("color 0F");
    printf("---MODIFICACION---\n");
    printf("-1- Descripcion\n");
    printf("-2- Importe\n");
    printf("-3- Cantidad\n");
    printf("-4- Salir\n");
    printf("Elija una opcion: ");

    scanf("%d",&opcion);
    system("cls");
    return opcion;
}






void modificar(struct Eproducto producto[],int cantidad)
{
int  codigo;
int esta;
int i;


char confirma;
int salir=0;

char codigoAuxStr[15];
char descripcionAuxStr[50];
char importeAuxStr[15];
char cantidadAuxStr[15];


int auxCantidad;
char auxDescripcion [50];

system("cls");
printf("---Modificacion---\n\n");

     for(i=0; i<cantidad; i++)
     {
        printf("\tComencemos con la Modificacion:");

        printf("\nIngrese su actual CODIGO: ");
        scanf("%d", &codigo);

        esta = buscarProducto(producto, cantidad, codigo);

        if(esta == -1)
        {
            printf("\nEl codigo  no se encuentra en el sistema\n\n");
            break;

        }
        else
        {
        printf("---Modificacion---\n\n");
        do{
        switch(menuModificacion())
        {

    case 1:


         {
         do{
            printf("\t [ Modificacion Descripcion ]\n");
            mostrarProducto(producto[esta]);



                if (!getStringLetras("\nIngrese la descripcion: ",descripcionAuxStr))
                 {
                  printf ("La descripcion deben ser letras \n");

                 while(!getStringLetras("Reingrese la descripcion ",descripcionAuxStr))
                  {
                      printf("NO INGRESE NUMEROS ");

                  }

                  }

            printf("Desea realizar la modificacion [s|n]: ");
            fflush(stdin);
            scanf("%c", &confirma);
            confirma = tolower(confirma);
          }while(confirma != 's' && confirma != 'n');

            if(confirma == 's')
            {
            strcpy(producto[i].descripcion,(strlwr(descripcionAuxStr)));
            printf("\nSe ha realizado la modificacion:\n\n");
            printf("Modificacion:\n ");
            mostrarProducto(producto[esta]);

            system("pause");
            break;
            }
           else{
            printf("\nSe ha cancelado la modificacion\n\n");
               }
           break;
        }


    case 2:
         {
         do{
            printf("\t [ Modificacion Importe ]\n");
            mostrarProducto(producto[esta]);


            if (!getStringNumerosFlotantes("\nIngrese el importe: ",importeAuxStr))
             {
                while(!getStringNumerosFlotantes("Reingrese importe: ",importeAuxStr))
                  {
                      printf("NO INGRESE LETRAS ");

                  }
             }

            printf("Desea realizar la modificacion [s|n]: ");
            fflush(stdin);
            scanf("%c", &confirma);
            confirma = tolower(confirma);
          }while(confirma != 's' && confirma != 'n');

            if(confirma == 's')
            {
            producto[i].importe=atof(importeAuxStr);

            printf("\nSe ha realizado la modificacion:\n\n");
            printf("Modificacion:\n ");

            mostrarProducto(producto[esta]);

            system("pause");
            break;
            }

            else{
            printf("\nSe ha cancelado la modificacion\n\n");
                }
           break;
        }



    case 3:

         {
         do{
            printf("\t [ Modificacion Cantidad ]\n");
            mostrarProducto(producto[esta]);


            if (!getStringNumeros("\nIngrese la cantidad: ",cantidadAuxStr))
            {

            printf ("El Codigo debe ser numerico\n");

                while(!getStringNumeros("Reingrese la cantidad: ",cantidadAuxStr))
                  {
                      printf("NO INGRESE LETRAS ");

                  }
            }

            printf("Desea realizar la modificacion [s|n]: ");
            fflush(stdin);
            scanf("%c", &confirma);
            confirma = tolower(confirma);
          }while(confirma != 's' && confirma != 'n');

            if(confirma == 's')
            {
            producto[i].cantidad = atoi(cantidadAuxStr);
            printf("\nSe ha realizado la modificacion:\n\n");
            printf("Modificacion:\n ");
            mostrarProducto(producto[esta]);

            system("pause");
            break;
            }
           else{
            printf("\nSe ha cancelado la modificacion\n\n");
               }
           break;
        }

        case 4:
        salir = 1;
        break;

        default:
        printf("\nOpcion Incorrecta\n\n");
        system("pause");
           }

        }while(salir!=1);
        break;



         }

         }
}


int menuListado(){
    int opcion;
    system("cls");
    system("color 0F");
    printf("---Listar---\n");
    printf("-1- Importe - Descripcion\n");
    printf("-2- Todos los productos que en cantidad son menor o igual a 10\n");
    printf("-3- Todos los productos que en cantidad son mayor  10\n");
    printf("-4- Salir\n");
    printf("Elija una opcion: ");

    scanf("%d",&opcion);
    system("cls");
    return opcion;
}





void ordenarProducto(struct Eproducto producto[], int cantidad)
{
int i;
int j;
struct Eproducto productoAux;

                for(i=0; i < cantidad - 1; i++)
                {
                    if(producto[i].estaLibre == 1)
                    {
                        continue;
                    }
                    for(j=i+1; j < cantidad; j++)
                    {
                        if(producto[i].estaLibre == 1)
                        {
                            continue;
                        }
                    if(producto[i].importe < producto[j].importe)
                {
                    productoAux = producto[j];
                    producto[j] = producto[i];
                    producto[i] = productoAux;
                }

                else if(producto[i].importe==producto[j].importe)
            {
                if(strcmp(producto[i].descripcion, producto[j].descripcion)>0)
            {
                productoAux = producto[i];
                producto[i] = producto[j];
                producto[j] = productoAux;
            }
            }
                    }
                }
                printf("Precio\t\t\tDescripcion\t\t\tCodigo\t\t\tCantidad\n");

       for(i=0; i<cantidad; i++)
    {
        if(producto[i].estaLibre==0)
        {
            printf("\n%f\t\t\t%s\t\t\t%d\t\t\t%d\n",producto[i].importe, producto[i].descripcion, producto[i].codigo , producto[i].cantidad);
        }



}
}

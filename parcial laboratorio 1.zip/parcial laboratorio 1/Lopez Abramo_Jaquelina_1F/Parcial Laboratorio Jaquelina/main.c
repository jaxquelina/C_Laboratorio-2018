#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "funciones.h"

#define CANT 1000


int main()
{
    struct Eproducto producto[CANT];
    struct Eprovedor provedores[5];


    int salir=0;

    inicializarProductos(producto, CANT);

    do
    {
        switch(menu())
        {

        case 1:
            altaProducto(producto,CANT);
            system("pause");
            break;


        case 2:
            modificar(producto,CANT);
            system("pause");
            break;


        case 3:
            bajaProducto(producto,CANT);
            system("pause");
            break;


        case 4:
              informar(producto,CANT);
              system("pause");

            break;
         case 5:
           listar(producto,CANT);
           system("pause");
           break;

         case 6:
             {
              hardCode(provedores);
             }
         case 7:
           salir = 1;
           system("pause");

            break;
        default:
            printf("\nOpcion Incorrecta\n\n");
            system("pause");
           }
      }while(salir != 1);

return 0;
}

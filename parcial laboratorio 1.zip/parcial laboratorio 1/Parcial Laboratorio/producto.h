#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
#include "producto.h"

typedef struct {
    int codigo;
    char descripcion[51];
    float importe;
    int cantidad;
    int estado;
    char nombreProveedor[51];

}eProducto;


typedef struct
{
    int estado;
    int idProveedor;
    char nombreProveedor[51];

}eProveedor;


/** \brief Contara la cantidad de productos que se ingresan.
 * \param producto Array hacer analizado.
 * \param canProducto Entero que indica el tama�o del array
 */
int cantidadDeProductosIngresados(eProducto producto[],int cantidadProductos);



/** \brief inicializa el estado del array de productos en 0.
 * \param producto Array hacer analizado.
 * \param canProducto Entero que indica el tama�o del array
 */
int inicializar(eProducto producto[],int cantProducto);




/** \brief Buscara si se podra cargar elementos es decir si hay espacio.
 * \param producto[] Array de estructura a ser recorrido
 * \param cantProducto Entero que determina la cantidad de estructuras del array
 * \return indice Numero entero que devuelve: -1 en caso de que no haya espacio, � el indice
 del vector en caso de que una estructura tenga su estado en 0(cero) por lo que se la considera vacia.
 */
int obtenerEspacioLibre(eProducto producto[],int cantProducto);



/** \brief Muestra un menu para las altas
 * \return Opcion Devuelve un caracter cargado con la opcion elegida por el usuario
 */
char menuAlta();


/** \brief tomando el menu permite realizar al usuario la alta de productos
 * \param produc Array de productos
 * \param proveed Array de proveedores
 * \param tamProd Entero que indica el tama�o del array productos
 * \param tamProv Entero que indica el tama�o del array proveedores
 */
void altaProductoYProveedor(eProducto[],int,eProveedor[],int);



/** \brief Se encarga de realizar la alta del producto.
 * \param produc Array de productos
 * \param proveed Array de proveedores
 * \param tamProd Entero que indica el tama�o del array productos
 * \param tamProv Entero que indica el tama�o del array proveedores
 */
void alta(eProducto producto[],int cantProducto,eProveedor proveedor[],int cantProveedor);



/** \brief Se encarga de realizar la baja de un producto.
 * \param producto Array de productos cargados.
 * \param cantidadProducto Entero que indica el tama�o del array productos
*/
int baja(eProducto producto[],int cantProducto);

/** \brief Muestra un menu para las modificaciones.
 * \return Opcion Devuelve un caracter cargado con la opcion elegida por el usuario.
 */
char menuModificar();

/** \brief Se encarga de realizar la modificacion de un producto.
 * \param producto Array de productos cargados.
 * \param cantidadProducto Entero que indica el tama�o del array productos
*/
int modificar(eProducto[],int);


/** \brief Se encarga de mostrar un producto,
 * \return producto Array de productos cargados.
*/
void mostrarProducto(eProducto);

/** \brief Se encarga de buscar un producto a traves de su codigo.
 * \return producto Array de productos cargados.
*/
int buscarProducto(eProducto lista[],int,int);


/** \brief Se encarga de mostrar recorriendo todos los  producto cargados.
 * \return producto Array de productos cargados.
*/
void mostrarTodos(eProducto[],int);


#endif // FUNCIONES_H_INCLUDED



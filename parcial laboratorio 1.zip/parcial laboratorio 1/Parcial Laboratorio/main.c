#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "producto.h"
#include "informes.h"
#define TAM 20
#define PROVE 6

int main()
{
    system("cls");
    system("color F0");
    char seguir='s';
    int opcion=0;
    int cant=0;
    eProducto producto[TAM];
    eProveedor prove[]= {{1,1,"apple"},{1,2,"microsoft"},{1,3,"ibm"},{1,4,"nike"},{1,5,"adidas"},{1,6,"loreal"}};
    inicializar(producto,TAM);


    while(seguir=='s')
    {

        cant=cantidadDeProductosIngresados(producto,TAM);
        system("color F0");
        printf("Bienvenido al Programa para cargar Productos :) \n\n");
        printf("1- Alta producto: Cantidad de productos ingresados:%d\n",cant);
        printf("2- Modificar producto\n");
        printf("3- Borrar producto\n");
        printf("4- Informar\n");
        printf("5- Listar\n");
        printf("6- Salir\n");
        printf("\nIndique opcion para comenzar: ");

        setbuf(stdin,NULL);
        scanf("%d",&opcion);

        switch(opcion)
        {
       case 1:
           system("cls");
            {

            altaProductoYProveedor(producto,TAM,prove,PROVE);
            break;
            }

        case 2:
            if(cant!=0)
            {
                modificar(producto,TAM);
            }
            else
            {
                printf("Cargue primero un producto\n");
            }
            break;
        case 3:
            system("cls");
            if(cant!=0)
            {
                baja(producto,TAM);
            }
            else
            {
                printf("Cargue primero un producto\n");

            }
            break;
        case 4:
            if(cant!=0)
            {
                informar(producto,TAM);
            }
            else
            {
                printf("Cargue primero un producto\n");

            }
            break;
        case 5:
            if(cant!=0)
            {
                listar(producto,prove,TAM,PROVE);

            }
            else
            {
                 printf("Cargue primero un producto\n");

            }
            break;
         case 6:
             seguir = 'n';
            break;

        default:
            system("cls");
            printf("\n\tOpcion invalida\n\n");
            break;
        }
        system("pause");
        system("cls");
    }

    return 0;
}


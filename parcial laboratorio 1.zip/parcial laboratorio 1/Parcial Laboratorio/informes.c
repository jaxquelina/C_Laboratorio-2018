#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "producto.h"
#include "informes.h"
#include "input.h"


char menuInformar()
{
    char opcion;
    system("cls");
    system("color 0F");
    printf("\n\n-------[ INFORMAR ]-------\n\n");
    printf("-A-Total y promedio de los importes, y cuantos productos superan ese promedio\n");
    printf("-B-Total y promedio de los importes, y cuantos productos no superan ese promedio\n");
    printf("-C-La cantidad de productos cuyo stock es menor o igual a 10\n");
    printf("-D-La cantidad de productos cuyo stock es mayor a 10\n");
    printf("-E-Salir\n");
    printf("Elija una opcion: ");
    fflush(stdin);
    scanf("%c",&opcion);
    opcion=toupper(opcion);

    return opcion;
}





void informarA(eProducto producto[],int cantidadProductos)
{
    float total=0;
    float promedio;
    int i;
    int contador=0;

    for(i=0; i<cantidadProductos; i++)
    {
        if(producto[i].estado!=0)
        {
            total=total+producto[i].importe;
            contador++;
        }
    }
    promedio=total/contador;
    printf("\n-A-Total y promedio de los importes, y cuantos productos superan ese promedio\n");
    printf("\nTOTAL: %.2f",total);
    printf("\nPROMEDIO: %.2f",promedio);
    for(i=0; i<cantidadProductos; i++)
    {
        if(producto[i].estado==1)
        {
            if(producto[i].importe>=promedio)
            {
                printf("\nProducto que supera el promedio(%.2f)de precio: %s--%.2f\n",promedio,producto[i].descripcion,producto[i].importe);

            }
        }
    }

}



void informarB(eProducto producto[],int cantidadProductos)
{
    float total=0;
    float promedio;
    int i;
    int contador=0;

    for(i=0; i<cantidadProductos; i++)
    {
        if(producto[i].estado!=0)
        {
            total=total+producto[i].importe;
            contador++;
        }
    }
    promedio=total/contador;
    printf("\n-B-Total y promedio de los importes, y cuantos productos superan no  ese promedio\n");
    printf("\nTOTAL: %.2f",total);
    printf("\nPROMEDIO: %.2f",promedio);
    for(i=0; i<cantidadProductos; i++)
    {
        if(producto[i].estado==1)
        {
            if(producto[i].importe<=promedio)
            {
                printf("\nProducto que supera el promedio(%.2f)de precio: %s--%.2f\n",promedio,producto[i].descripcion,producto[i].importe);

            }
        }
    }

}



void informarC(eProducto producto[],int cantidadProductos)
{
    int i;
    printf("\n-C-La cantidad de productos cuyo stock es menor o igual a 10\n");

    for(i=0; i<cantidadProductos; i++)
    {
        if(producto[i].estado==1)
        {
            if(producto[i].cantidad<=10)
            {
                printf("\nProducto con stock menor o igual a 10: %s---cantidad:%d\n",producto[i].descripcion,producto[i].cantidad);

            }
        }
    }
}



void informarD(eProducto producto[],int cantidadProductos)
{
    int i;

    printf("\n-D-La cantidad de productos cuyo stock es mayor a 10\n");

    for(i=0; i<cantidadProductos; i++)
    {
        if(producto[i].estado==1)
        {
            if(producto[i].cantidad>10)
            {
                printf("\nProducto con stock mayor a 10: %s---cantidad:%d\n",producto[i].descripcion,producto[i].cantidad);

            }
            else
            {

                printf("Ningun producto ingresado supero una cantidad mayor a 10");
            }
        }
    }
}





void informar(eProducto producto[],int cantidadProductos)
{
    int salir=0;
    do
    {
        switch(menuInformar())
        {
        case 'A':
            system("cls");
            informarA(producto,cantidadProductos);
            system("pause");
            break;
        case 'B':
            system("cls");
            informarB(producto,cantidadProductos);
            system("pause");
            break;
        case 'C':
            system("cls");
            informarC(producto,cantidadProductos);
            system("pause");
            break;
        case 'D':
            system("cls");
            informarD(producto,cantidadProductos);
            system("pause");
            break;
        case 'E':
            salir=1;
            break;
        }
    }
    while(salir!=1);
}


char menuListar()
{
    char opcion;
    system("cls");
    system("color 0F");
    printf("\n\n-------LISTAR-------\n\n");
    printf("-A-Listado de los productos por importe(descendente) y descripcion(ascendente)\n");
    printf("-B-Todos los productos que en cantidad son menos o igual a 10\n");
    printf("-C-Todos los productos que en cantidad son mayor a 10\n");
    printf("-D-Todos los productos que superan el promedio de los importes\n");
    printf("-E-Todos los productos que no superan el promedio de los importes\n");
    printf("-F-Todos los proveedores cuya cantidad de producto es menor o igual a 10\n");
    printf("-G-Todos los productos provistos por cada proveedor\n");
    printf("-H-Todos los productos provistos por un proveedor determinado\n");
    printf("-I-El proveedor que provee mas productos, mostrando productos\n");
    printf("-J-El proveedor que provee menos productos, mostrando ese producto\n");
    printf("-K-El proveedor que provee el producto mas caro, mostrando ese producto\n");
    printf("-L-El proveedor que provee el producto mas barato, mostrando ese producto\n");
    printf("-M-Salir\n");
    printf("Elija una opcion: ");
    fflush(stdin);
    scanf("%c",&opcion);
    opcion=toupper(opcion);
    return opcion;
}



void listar(eProducto producto[],eProveedor proveedor[],int tamanioProducto,int tamanioProveedor)
{
    int salir=0;
    do
    {
        switch(menuListar())
        {
        case 'A':
            system("cls");
            listarA(producto,tamanioProducto);
            system("pause");
            break;
        case 'B':
            system("cls");
            listarB(producto,tamanioProducto);
            system("pause");
            break;
        case 'C':
            system("cls");
            listarC(producto,tamanioProducto);
            system("pause");
            break;
        case 'D':
            system("cls");
            listarD(producto,tamanioProducto);
            system("pause");
            break;
        case 'E':
            system("cls");
            listarE(producto,tamanioProducto);
            system("pause");
            break;
        case 'F':
            system("cls");
            listarF(producto,tamanioProducto,proveedor,tamanioProveedor);
            system("pause");
            break;
        case 'G':
            system("cls");
            listarG(producto,tamanioProducto,proveedor,tamanioProveedor);
            system("pause");
            break;
        case 'H':
            system("cls");
            listarH(producto,tamanioProducto,proveedor,tamanioProveedor);
            system("pause");
            break;
        case 'I':
            system("cls");
            listarI(producto,tamanioProducto,proveedor,tamanioProveedor);
            system("pause");
            break;
        case 'J':
            system("cls");
            listarJ(producto,tamanioProducto,proveedor,tamanioProveedor);
            system("pause");
            break;
        case 'K':
            system("cls");
            listarK(producto,tamanioProducto,proveedor,tamanioProveedor);
            system("pause");
            break;
        case 'L':
            system("cls");
            listarL(producto,tamanioProducto,proveedor,tamanioProveedor);
            system("pause");
            break;
        case 'M':
            salir=1;
            break;
        }
    }
    while(salir!=1);
}


void listarA(eProducto producto[],int tamanioProducto)
{
    eProducto aux;
    int i,j;
    printf("-A-Listado de los productos por importe(descendente) y descripcion(ascendente)\n");

    for(i=0; i<tamanioProducto-1; i++)
    {
        for(j=i+1; j<tamanioProducto; j++)
        {
            if(producto[i].importe<producto[j].importe)
            {
                aux=producto[i];
                producto[i]=producto[j];
                producto[j]=aux;
            }
            else if(producto[i].importe==producto[j].importe)
            {

                if(strcmp(producto[i].descripcion,producto[j].descripcion)<0)
                {
                    aux=producto[i];
                    producto[i]=producto[j];
                    producto[j]=aux;
                }
            }
        }
    }

    mostrarTodos(producto,tamanioProducto);
    return;
}



void listarB(eProducto producto[],int tamanioProducto)
{
    int i;
    printf("\n-B-Todos los productos que en cantidad son menos o igual a 10\n");
    for(i=0; i<tamanioProducto; i++)
    {
        if(producto[i].estado==1)
        {
            if(producto[i].cantidad<=10)
            {
                printf("\n\tproducto con stock menor a 10: %s---cantidad:%d\n",producto[i].descripcion,producto[i].cantidad);

            }
            else
                printf("No existe ningun producto que en cantidad es menor a 10");
        }
    }
}



void listarC(eProducto producto[],int tamanioProducto)
{
    {
    int i;
    printf("\n-C-Todos los productos que en cantidad son mayor a 10\n");
    for(i=0; i<tamanioProducto; i++)
    {
        if(producto[i].estado==1)
        {
            if(producto[i].cantidad>10)
            {
                printf("\nProducto con stock mayor a 10: %s---cantidad:%d\n",producto[i].descripcion,producto[i].cantidad);

            }
        }
    }
}

}


void listarD(eProducto producto[],int tamanioProducto)
{
    float promedio;
    float acumulador=0;
    int i;
    int contador=0;
    for(i=0; i<tamanioProducto; i++)
    {
        if(producto[i].estado!=0)
        {
            acumulador=acumulador+producto[i].importe;
            contador++;
        }
    }
    promedio=acumulador/contador;
    printf("\n-D-Todos los productos que superan el promedio de los importes\n");
    for(i=0; i<tamanioProducto; i++)
    {
        if(producto[i].estado!=0 && producto[i].importe>promedio)
        {
                printf("\nproductos que superan el promedio de los importes: %s---cantidad:%d\n",producto[i].descripcion,producto[i].cantidad);
        }
    }
}



void listarE(eProducto producto[],int tamanioProducto)
{
    float promedio;
    float acumulador=0;
    int i;
    int contador=0;
    for(i=0; i<tamanioProducto; i++)
    {
        if(producto[i].estado!=0)
        {
            acumulador=acumulador+producto[i].importe;
            contador++;
        }
    }
    promedio=acumulador/contador;
    printf("\n-E-Todos los productos que no superan el promedio de los importes\n");
    for(i=0; i<tamanioProducto; i++)
    {
        if(producto[i].estado!=0 && producto[i].importe>promedio)
        {
                printf("\nproductos que superan el promedio de los importes: %s---cantidad:%d\n",producto[i].descripcion,producto[i].cantidad);
        }
    }
}


void listarF(eProducto producto[],int tamanioProducto,eProveedor prov[],int cantidadProveedores)
{
    int i,j;

    printf("\n-F-Todos los proveedores cuya cantidad de producto es menor o igual a 10\n");

    printf("\nproveedor \t---\tproductos\n");
    for(i=0; i<cantidadProveedores; i++)
    {
        for(j=0; j<tamanioProducto; j++)
        {
            if(strcmp(prov[i].nombreProveedor,producto[j].nombreProveedor) == 0 &&producto[j].estado==1 && producto[j].cantidad<=10 )
            {
                printf("\n%s\t---\t%-15s\n",prov[i].nombreProveedor,producto[j].descripcion);

            }

         }


    }

}



void listarG(eProducto producto[],int tamanioProductos,eProveedor proveedores[],int cantidadProveedores)
{
    int i;
    int j;

    printf("\n-G-Todos los productos provistos por cada proveedor\n");
    printf("\nproveedor \t---\tproductos\n");
    for(i=0; i<cantidadProveedores; i++)
    {
        for(j=0; j<tamanioProductos; j++)
        {
            if(strcmp(proveedores[i].nombreProveedor,producto[j].nombreProveedor) == 0 && producto[j].estado==1)
            {
                printf("\n%s\t---\t%-15s\n",proveedores[i].nombreProveedor,producto[j].descripcion);
            }
        }
    }
}





void listarH(eProducto producto[],int cantidadProductos,eProveedor proveedor[],int cantidadProveedores)
{
    int i;
    int j;
    int auxiliar;
    char auxiliarProveedor[60];
    do
    {
        printf("[ Lista de proveedores] \n");
        for(i=0; i<cantidadProveedores; i++)
        {
            printf("\tProveedor: %s\n",proveedor[i].nombreProveedor);
        }
        setbuf(stdin,NULL);
        auxiliar=getStringDescripcion("\nIngrese el nombre del proveedor: ",auxiliarProveedor);
        if(auxiliar!=1 || (strlen(auxiliarProveedor)>50))
        {
            printf("\nERROR. Nombre incorrecto.\n\n");
            system("pause");
            system("cls");
        }
    }
    while(auxiliar!=1 || (strlen(auxiliarProveedor)>60));
    strlwr(auxiliarProveedor);
    for(i=0; i<cantidadProveedores; i++)
    {
        if(strcmp(auxiliarProveedor,proveedor[i].nombreProveedor)==0)
        {
            break;
        }
    }
    system("cls");
    printf("\n\tProveedor: %s\n",proveedor[i].nombreProveedor);
    printf("Codigo\tPrecio\tCantidad\tDescripcion\n");
    for(j=0; j<cantidadProductos; j++)
    {
        if(strcmp(proveedor[i].nombreProveedor,producto[j].nombreProveedor)==0 && producto[j].estado==1)
        mostrarProducto(producto[j]);
    }
}



void listarI(eProducto producto[],int cantidadProductos,eProveedor proveedor[],int cantidadProveedores)
{
    int i;
    int j;
    int maximo=0;
    int minimo=0;
    int acumulador[cantidadProveedores];


    for(i=0; i<cantidadProveedores; i++)
    {
        acumulador[i]=0;
    }

    for(i=0; i<cantidadProveedores; i++)
    {
        for(j=0; j<cantidadProductos; j++)
        {
            if(strcmp(proveedor[i].nombreProveedor,producto[j].nombreProveedor) == 0 &&producto[j].estado==1)
            {
                acumulador[i]++;
            }
        }
    }

    maximo=acumulador[0];
    minimo=acumulador[0];

    for(i=0; i<cantidadProveedores; i++)
    {
        if(maximo<acumulador[i])
        {
            maximo=acumulador[i];

        }
        if(minimo>acumulador[i])
        {
            minimo=acumulador[i];

        }
    }
    printf("[ Proveedor con mas producto ]\n");
        printf("Proveedor\tDescripcion\n");

    for(i=0; i<cantidadProveedores; i++)
    {
        for(j=0; j<cantidadProductos; j++)
        {
            if(maximo==acumulador[i])
            {
                if(strcmp(proveedor[i].nombreProveedor,producto[j].nombreProveedor) == 0 &&producto[j].estado==1)
                {
                    printf("%s\t\t%-20s\n",proveedor[i].nombreProveedor,producto[j].descripcion);
                }
            }
        }
    }
}




void listarJ(eProducto producto[],int cantidadProductos,eProveedor proveedor[],int cantidadProveedores)
{
    int i;
    int j;
    int maximo=0;
    int minimo=0;
    int acumulador[cantidadProveedores];

    maximo=acumulador[0];
    minimo=acumulador[0];

    for(i=0; i<cantidadProveedores; i++)
    {
         if(acumulador[i]<maximo)
            {
               maximo=acumulador[i];
            }
            else
            {
                minimo=acumulador[i];
            }
        }


    printf("[ Proveedor con menos producto ]\n");
    printf("Proveedor\tDescripcion\n");
    for(i=0; i<cantidadProveedores; i++)
    {
        for(j=0; j<cantidadProductos; j++)
        {
            if(minimo=acumulador[i])
            {
                if(strcmp(proveedor[i].nombreProveedor,producto[j].nombreProveedor) == 0 && producto[j].estado==1)
                {
                    printf("%s\t\t%-20s\n",proveedor[i].nombreProveedor,producto[j].descripcion);
                }
            }
        }
    }


}


void listarK(eProducto producto[],int cantidadProductos,eProveedor proveedor[],int cantidadProveedores)
{
    int i;
    int j;
    float maximo=0;
    float minimo=0;

    maximo=producto[0].importe;
    minimo=producto[0].importe;

    for(i=0; i<cantidadProveedores; i++)
    {
        for(j=0; j<cantidadProductos; j++)
        {
            if(strcmp(proveedor[i].nombreProveedor,producto[j].nombreProveedor) == 0 && producto[j].estado==1)
            {

                if(maximo<producto[j].importe)
                {
                    maximo=producto[j].importe;

                }
                if(minimo>producto[j].importe)
                {
                    minimo=producto[j].importe;

                }
            }
        }
    }
    printf("\n\n[ Producto mas caro]");
    printf("\tprecio\tProveedor\n");
    for(i=0; i<cantidadProveedores; i++)
    {
        for(j=0; j<cantidadProductos; j++)
        {
            if(strcmp(proveedor[i].nombreProveedor,producto[j].nombreProveedor) == 0 && producto[j].estado==1)
            {
                if(maximo==producto[j].importe)
                {
                    printf("\n%s\t\t%.2f\t%s\n",producto[j].descripcion,producto[j].importe,producto[j].nombreProveedor);
                }

            }
        }
    }
}





void listarL(eProducto producto[],int cantidadProductos,eProveedor proveedor[],int cantidadProveedores)
{

    int i;
    int j;
    float maximo=0;
    float minimo=0;

    maximo=producto[0].importe;
    minimo=producto[0].importe;

    for(i=0; i<cantidadProveedores; i++)
    {
        for(j=0; j<cantidadProductos; j++)
        {
            if(strcmp(proveedor[i].nombreProveedor,producto[j].nombreProveedor) == 0 && producto[j].estado==1)
            {

                if(maximo<producto[j].importe)
                {
                    maximo=producto[j].importe;

                }
                if(minimo>producto[j].importe)
                {
                    minimo=producto[j].importe;

                }
            }
        }
    }

    printf("[Producto mas barato]");
    printf("\tprecio\tProveedor\n");
    for(i=0; i<cantidadProveedores; i++)
    {
        for(j=0; j<cantidadProductos; j++)
        {
            if(strcmp(proveedor[i].nombreProveedor,producto[j].nombreProveedor) == 0 && producto[j].estado==1)
            {
                if(minimo==producto[j].importe)
                {
                    printf("\n%s\t\t%-15.2f\t%-15s\n",producto[j].descripcion,producto[j].importe,producto[j].nombreProveedor);
                }

            }
        }
    }
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "producto.h"
#include "informes.h"
#include "input.h"


int cantidadDeProductosIngresados(eProducto producto[],int cantidadProductos)
{
    int i;
    int acumulador=0;
    for(i=0; i<cantidadProductos; i++)
    {
        if(producto[i].estado==1)
        {
            acumulador++;
        }


    }
    return acumulador;
}



int inicializar(eProducto producto[],int cantidadProducto)
{
    int i;
    for(i=0; i<cantidadProducto; i++)
    {
        producto[i].estado=0;
    }
    return 0;
}



int obtenerEspacioLibre(eProducto producto[],int cantidadProducto)
{
    int i;
    int indice=-1;

    for(i=0; i<cantidadProducto; i++)
    {
        if(producto[i].estado == 0)
        {
            indice=i;
            break;
        }
    }

    return indice;
}




char menuAlta()
{
    char opcion;
    system("cls");
    printf("\n\n-------[ COMENCEMOS A INGRESAR PRODUCTOS: ]-------\n\n");
    printf("-1- Alta Productos\n");
    printf("-2- Salir\n");
    printf("Elija una opcion: ");
    fflush(stdin);
    scanf("%c",&opcion);
    return opcion;
}




void altaProductoYProveedor(eProducto producto[],int cantProducto,eProveedor proveedor[],int cantProveedor)
{
    eProducto auxProducto;
    int salir=0,i;
    do
    {
        switch(menuAlta())
        {
        case '1':
            system("cls");
            printf("Comencemos a Ingresar el producto: \n ");
            alta(producto,cantProducto,proveedor,cantProveedor);
            system("pause");
            break;


        case '2':
            salir=1;
            break;
        default:
            printf("\n\nOpcion incorrecta\n\n");
            system("pause");
            break;
        }
    }
    while(salir!=1);
}




void alta(eProducto producto[],int cantidadProductos,eProveedor proveedor[],int cantidadProveedores)
{

    int indice;
    int esta;
    int auxiliar;
    int i;
    int codigo;
    int flag=0;
    char auxiliarCodigo[21];
    char auxiliarProveedor[51];
    int preguntar='n';
    eProducto auxiliarProducto;



    indice=obtenerEspacioLibre(producto,cantidadProductos);
    if(indice !=-1)
    {
        do
        {
            do
            {
                auxiliar=getStringNumeros("Ingrese el Codigo: ",auxiliarCodigo);
                if(auxiliar!=1)
                {
                    printf("\n ERROR. Codigo Incorrecto solo debe utilizar numeros :) \n\n");
                }
                else
                {
                    codigo=atoi(auxiliarCodigo);
                }
            }
            while(auxiliar!=1);

            esta=buscarProducto(producto,cantidadProductos,codigo);
            if(esta==-1)
            {
                auxiliarProducto.codigo=codigo;
                do
                {
                    auxiliar=getStringDescripcion("ingrese la Descripcion: ",auxiliarProducto.descripcion);
                    if(auxiliar!=1 || (strlen(auxiliarProducto.descripcion)>50))
                    {
                        printf("\n ERROR. Descripcion incorrecta\n\n");
                    }
                }
                while(auxiliar!=1 || (strlen(auxiliarProducto.descripcion)>50));

                do
                {
                    auxiliar=getStringFloat("Ingrese  importe:",auxiliarCodigo);
                    if(auxiliar!=1)
                    {
                        printf("\n ERROR. Importe incorrecto\n\n");
                    }
                    else
                    {
                        auxiliarProducto.importe=atof(auxiliarCodigo);
                    }
                }
                while(auxiliar!=1);

                do
                {
                    auxiliar=getStringNumeros("Ingrese cantidad de stock: ",auxiliarCodigo);
                    if(auxiliar!=1)
                    {
                        printf("\n ERROR. Cantidad incorrecta.\n\n");
                    }
                    else
                    {
                        auxiliarProducto.cantidad=atoi(auxiliarCodigo);
                    }
                }
                while(auxiliar!=1);
                do
                {
                    do
                    {
                        system("cls");
                        printf("Proveedores: \n");
                        for(i=0; i<cantidadProveedores; i++)
                        {
                            printf("\tProveedor: %s\n",proveedor[i].nombreProveedor);
                        }
                        setbuf(stdin,NULL);
                        auxiliar=getStringDescripcion("\nIngrese nombre del proveedor de su producto:",auxiliarProveedor);
                        if(auxiliar!=1 || (strlen(auxiliarProveedor)>50))
                        {
                            printf("\n ERROR. Descripcion incorrecta.\n\n");

                        }
                    }
                    while(auxiliar!=1 || (strlen(auxiliarProveedor)>50));
                    strlwr(auxiliarProveedor);
                    for(i=0; i<cantidadProveedores; i++)
                    {
                        if(strcmp(auxiliarProveedor,proveedor[i].nombreProveedor)==0)
                        {
                            flag=1;
                            strcpy(auxiliarProducto.nombreProveedor,proveedor[i].nombreProveedor);
                            auxiliarProducto.estado=1;
                            break;
                        }
                        else
                        {
                            flag=0;

                        }
                    }
                    if(flag==0)
                    {
                        printf("\n ERROR. Proveedor incorrecto\n");
                        system("pause");
                    }
                }

                while(flag!=1);
            }
            else
            {
                printf("Ese Codigo ya esta repetido POR FAVOR REINGRESE.\n");
                system("pause");
            }
        }
        while(esta!=-1);

    }
    else
    {
        printf("nNo queda mas espacio para seguir cargando productos. :( \n");
    }


    system("cls");
    ("Producto Cargado: \n");
    printf("Descripcion: %s\nCodigo:%d\nimporte: %.2f\nStock:%d\nProveedor: %s\n\n",auxiliarProducto.descripcion,auxiliarProducto.codigo,auxiliarProducto.importe,auxiliarProducto.cantidad,auxiliarProducto.nombreProveedor);
    printf("Esta seguro que desea cargar el producto? [s|n]: ");
    setbuf(stdin,NULL);
    scanf("%c",&preguntar);
    preguntar=tolower(preguntar);



    if(preguntar=='s')
    {
        producto[indice]=auxiliarProducto;
        printf("\nFelidades el producto a sido cargado. \n");
    }
    else
        printf("\n El producto no se a cargado.\n");
    return;
}




int baja(eProducto producto[],int cantProducto)
{
    int auxiliar;
    int auxiliarIndice;
    int codigo;
    char auxiliarCodigo[15];
    char seguir='n';
    do
    {
        printf("\n\n-------[ BORRAR PRODUCTO ]-------\n\n");
        auxiliar=getStringNumeros("Por favor ingrese del producto para comenzar: ",auxiliarCodigo);
        if(auxiliar!=1)
        {
            printf("\nERROR. Codigo Incorrecto reingrese.\n");
        }
        else
        {
            codigo=atoi(auxiliarCodigo);
        }
    }
    while(auxiliar!=1);

    auxiliarIndice=buscarProducto(producto,cantProducto,codigo);
    if(auxiliarIndice == -1  || producto[auxiliarIndice].estado==0)
    {
        printf("ERROR.El codigo: %d ingresado no se ha encontrado.",codigo);
    }
    else
    {
        mostrarProducto(producto[auxiliarIndice]);

        printf("�Seguro que desea borrar el producto? [s|n]: ");
        setbuf(stdin,NULL);
        scanf("%c",&seguir);
        seguir=tolower(seguir);
        if(seguir=='s')
        {
            producto[auxiliarIndice].estado=0;
            printf("Felicitaciones. El producto a sido dado de baja.\n");
        }
        else
        {
            printf("El producto no se a dado de baja.\n");
        }
    }
    return 0;
}


int menuModificacion(){
    int opcion;
    system("cls");
    system("color 0F");
    printf("---MODIFICACION---\n");
    printf("-1- Descripcion\n");
    printf("-2- Importe\n");
    printf("-3- Cantidad\n");
    printf("-4- Salir\n");
    printf("Elija una opcion: ");

    scanf("%d",&opcion);
    system("cls");
    return opcion;
}





int modificar(eProducto producto[],int cantidadProductos)
{
    eProducto auxProducto;
    int aux,auxIndice,codigo;
    char auxVerificar[20];
    char seguir='s';
    int opcion=0;
    do
    {
        aux=getStringNumeros("Codigo del producto a modificar: ",auxVerificar);
        if(aux!=1)
        {
            printf("\n Codigo incorrecto, recuerde utilizar solo numeros \n\n");
        }
        else
        {
            codigo=atoi(auxVerificar);
        }
    }
    while(aux!=1);

    auxIndice=buscarProducto(producto,cantidadProductos,codigo);
    if(auxIndice == -1  || producto[auxIndice].estado==0)
    {
        printf("El codigo: %d no se ha encontrado en el sistema.\n",codigo);
    }
    else
    {

        auxProducto=producto[auxIndice];
        mostrarProducto(auxProducto);
        printf("�Es el producto que desea modificar? [s|n]: ");
        setbuf(stdin,NULL);
        scanf("%c",&seguir);
        seguir=tolower(seguir);
        while(seguir=='s')
        {

            switch(menuModificacion())
            {
            case 1:
                do
                {

                    printf("\t [ Modificacion Descripcion ]\n");
                    mostrarProducto(auxProducto);
                    aux=getStringDescripcion("Ingrese la nueva descripcion: ",auxProducto.descripcion);
                    if(aux!=1 || (strlen(auxProducto.descripcion)>61))
                    {
                        printf("\nERROR. Descripcion incorrecta. \n\n");
                    }
                }
                while(aux!=1 || (strlen(auxProducto.descripcion)>61));
                printf("Modificacion realizada con exito \n");
                mostrarProducto(auxProducto);

                break;
            case 2:
                do
                {
                    printf("[ Modificacion Importe ]\n");
                    mostrarProducto(auxProducto);
                    aux=getStringFloat("Ingrese el nuevo importe del producto: ",auxVerificar);
                    if(aux!=1)
                    {
                        printf("\nERROR. Importe no valido.\n\n");
                    }
                    else
                    {
                        auxProducto.importe=atof(auxVerificar);
                    }
                }
                while(aux!=1);
                printf("Modificacion realizada con exito");
                mostrarProducto(auxProducto);
                break;
            case 3:
                do
                {
                    printf("\t [ Modificacion Cantidad Stock ]\n");
                    mostrarProducto(auxProducto);
                    aux=getStringNumeros("Ingrese el nuevo stock:",auxVerificar);
                    if(aux!=1)
                    {
                        printf("\nERROR.cantidad incorrecta, utilice solo valores numericos.\n\n");
                    }
                    else
                    {
                        auxProducto.cantidad=atoi(auxVerificar);
                    }
                }
                while(aux!=1);
                printf("Modificacion realizada con exito");
                mostrarProducto(auxProducto);

                break;
            case 4:
                seguir = 'n';
                break;

            default:
                system("cls");
                printf("\n\tOpcion invalida\n\n");
                break;
            }
            system("pause");
            system("cls");
        }
        printf("\n\n\t\tModificaciones\n\n");
        mostrarProducto(auxProducto);
        printf("�Desea guardar los cambios? [s|n]\n");
        setbuf(stdin,NULL);
        scanf("%c",&seguir);
        seguir=tolower(seguir);
        if(seguir=='s')
        {
            producto[auxIndice]=auxProducto;
            printf("\nFelicitaciones los cambios se han guardado :) \n");
        }
        else
        {
            printf("No se ha modificado el producto.\n");
        }
    }



    return 0;
}

void mostrarProducto(eProducto producto)
{
    printf("%d\t%.2f\t%d\t\t%s\n",producto.codigo,producto.importe,producto.cantidad,producto.descripcion);
    return;
}


int buscarProducto(eProducto producto[],int cantidadProductos,int codigo)
{
    int i;
    int indice= -1;
    for(i=0; i<cantidadProductos; i++)
    {
        if(producto[i].estado==1 && producto[i].codigo==codigo)
        {
            indice=i;
            break;
        }
    }
    return indice;
}


void mostrarTodos(eProducto producto[],int cantidad)
{
    int i;
    printf("Codigo\tPrecio\tCantidad\tDescripcion\n");
    for(i=0; i<cantidad; i++)
    {
        if(producto[i].estado ==1)
        {
            mostrarProducto(producto[i]);
        }

    }
    return;
}

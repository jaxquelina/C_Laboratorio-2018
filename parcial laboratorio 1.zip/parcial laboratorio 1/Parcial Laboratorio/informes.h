#ifndef INFORMES_H_INCLUDED
#define INFORMES_H_INCLUDED




/** \brief realiza la opcion elegida por el usuario del menu informar
 * \param Array a ser analizado
 * \param  Entero que indica el tama�o del array
 */
void informar(eProducto[],int);


/** \brief Total y promedio de los importes, y cuantos productos superan ese promedio
 * \param Array a ser analizado
 * \param Entero que indica el tama�o del array
 */
void informarA(eProducto[],int);



/** \brief Total y promedio de los importes, y cuantos productos no superan ese promedio
 * \param  Array a ser analizado
 * \param Entero que indica el tama�o del array
 */
void informarB(eProducto[],int);



/** \brief La cantidad de productos cuyo stock es menor o igual a 10
 * \param Array a ser analizado
 * \param Entero que indica el tama�o del array
 */
void informarC(eProducto[],int);


/** \brief La cantidad de productos cuyo stock es mayor a 10
 * \param Array a ser analizado
 * \param Entero que indica el tama�o del array
 */
void informarD(eProducto[],int);



/** \brief muestra el menu de opciones para informar
 * \return char Devuelve el caracter correspondiente a la oopcion elegida por el usuario
 */
char menuInformar();



/** \brief muestra el menu de opciones para listar
 * \return char Devuelve el caracter correspondiente a la oopcion elegida por el usuario
 */
char menuListar();



/** \brief realiza la opcion elegida por el usuario del menu listar
 * \param  Array de productos
 * \param  Array de proveedores
 * \param tamProd indica el tama�o del array productores
 * \param tamProv indica el tama�o del array productos
 */
void listar(eProducto produc[],eProveedor proveed[],int tamProd,int tamProv);

/** \brief Listado de los productos por importe(descendente) y descripcion(ascendente)
 * \param Array a ser analizado
 * \param Entero que indica el tama�o del array
 */
void listarA(eProducto produc[],int tam);


/** \brief Todos los productos que en cantidad son menos o igual a 10
 * \param Array a ser analizado
 * \param Entero que indica el tama�o del array
 */
void listarB(eProducto produc[],int tam);


/** \brief Todos los productos que en cantidad son mayor a 10
 * \param Array a ser analizado
 * \param Entero que indica el tama�o del array
 */
void listarC(eProducto produc[],int tam);


/** \brief Todos los productos que superan el promedio de los importes
 * \param  Array a ser analizado
 * \param  Entero que indica el tama�o del array
 */
void listarD(eProducto produc[],int tam);

/** \brief Todos los productos que no superan el promedio de los importes
 * \param  Array a ser analizado
 * \param  Entero que indica el tama�o del array
 */
void listarE(eProducto produc[],int tam);


/** \brief Todos los proveedores cuya cantidad de producto es menor o igual a 10
 * \param  Array de productos
 * \param  Entero que indica el tama�o del array productos
 * \param  Array de proveedores
 * \param  Entero que indica el tama�o del array proveedores
 */
void listarF(eProducto producto[],int tam,eProveedor prov[],int cant);



/** \brief Todos los productos provistos por cada proveedor
 * \param Array de productos
 * \param Entero que indica el tama�o del array productos
 * \param Array de proveedores
 * \param Entero que indica el tama�o del array proveedores
 */
void listarG(eProducto producto[],int tam,eProveedor prov[],int cant);


/** \brief Todos los productos provistos por un proveedor determinado
 * \param Array de productos
 * \param Entero que indica el tama�o del array productos
 * \param Array de proveedores
 * \param Entero que indica el tama�o del array proveedores
 */
void listarH(eProducto producto[],int tam,eProveedor prov[],int cant);


/** \brief El proveedor que provee mas productos, mostrando productos
 * \param Array de productos
 * \param Entero que indica el tama�o del array productos
 * \param Array de proveedores
 * \param Entero que indica el tama�o del array proveedores
 */
void listarI(eProducto producto[],int tam,eProveedor prov[],int cant);

/** \brief El proveedor que provee menos productos, mostrando ese producto
 * \param Array de productos
 * \param Entero que indica el tama�o del array productos
 * \param Array de proveedores
 * \param Entero que indica el tama�o del array proveedores
 */
void listarJ(eProducto producto[],int tam,eProveedor prov[],int cant);




/** \brief El proveedor que provee el producto mas caro, mostrando ese producto
 * \param Array de productos
 * \param Entero que indica el tama�o del array productos
 * \param Array de proveedores
 * \param Entero que indica el tama�o del array proveedores
 */
void listarK(eProducto producto[],int tam,eProveedor prov[],int cant);



/** \brief El proveedor que provee el producto mas barato, mostrando ese producto
 * \param Array de productos
 * \param Entero que indica el tama�o del array productos
 * \param Array de proveedores
 * \param Entero que indica el tama�o del array proveedores
 */
void listarL(eProducto producto[],int tam,eProveedor prov[],int cant);

#endif

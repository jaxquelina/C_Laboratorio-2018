#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <conio.h>

#include "arraylist.h"
#include "validaciones.h"
#include "funciones.h"


eEmpleado* new_Empleado()
{
    eEmpleado* retorno = NULL;

    retorno=(eEmpleado*)malloc(sizeof(eEmpleado));
    if(retorno!=NULL)
    {
        strcpy(retorno->nombre,"");
        retorno->id=0;
        retorno->horasTrabajo=0;
        retorno->sueldo=0;
    }
    return retorno;
}




int mostrar_Empleado(eEmpleado* empleado)
{
    int retorno=-1;

    if(empleado!=NULL)
    {
        printf("ID:%d\tNombre:%s\tHoras:%d\n",empleado->id,empleado->nombre,empleado->horasTrabajo);
        retorno=0;
    }
    return retorno;
}





eEmpleado* empleado_Parametros(int id, char* nombre,int horasTrabajo)
{
    eEmpleado* retorno = NULL;

    retorno = new_Empleado();
    if(retorno!=NULL)
    {
        strcpy(retorno->nombre,nombre);
        retorno->id=id;
        retorno->horasTrabajo=horasTrabajo;
    }
    return retorno;
}





int parser_parseEmpleados(char* fileName, ArrayList* listaEmpleados)
{
    char id[5];
    char nombre[50];
    char horasTrabajo[5];

    int auxiliarId;
    int auxiliarHorasTrabajo;

    int retorno=-1;
    eEmpleado* empleado;

    FILE* punteroFile = fopen (fileName,"r");

    if(punteroFile!=NULL)
    {
        retorno =0;
    }
    while(!feof(punteroFile))
    {
        fscanf(punteroFile, "%[^,],%[^,],%[^\n]\n",id,nombre,horasTrabajo);

        auxiliarId=atoi(id);//parseo el ID

        auxiliarHorasTrabajo=atoi(horasTrabajo);//parseo las HORAS DE TRABAJO

        empleado= empleado_Parametros(auxiliarId,nombre,auxiliarHorasTrabajo);
        mostrar_Empleado(empleado);

        if(listaEmpleados->add(listaEmpleados,empleado)==0);
        {
            retorno=1;
        }
    }
    fclose(punteroFile);
    return retorno;
}




void calcularLosSueldos(void* punteroAux)
{
    if(((eEmpleado*)punteroAux)!=NULL)
     {

        if(((eEmpleado*)punteroAux)->horasTrabajo<=176)
            {
            ((eEmpleado*)punteroAux)->sueldo = ((eEmpleado*)punteroAux)->horasTrabajo * 180;
            }
            if(((eEmpleado*)punteroAux)->horasTrabajo>176 && ((eEmpleado*)punteroAux)->horasTrabajo<=208)
            {
            ((eEmpleado*)punteroAux)->sueldo = ((eEmpleado*)punteroAux)->horasTrabajo * 270;
            }
        if(((eEmpleado*)punteroAux)->horasTrabajo>208 && ((eEmpleado*)punteroAux)->horasTrabajo<=240)
            {
            ((eEmpleado*)punteroAux)->sueldo = ((eEmpleado*)punteroAux)->horasTrabajo * 360;
            }
    }
}


int generarArchivoSueldos(char* fileName,ArrayList* listaEmpleados)
{
int retorno = -1;
int i;
    eEmpleado* auxEmpleados = new_Empleado();

    FILE *punteroFile = fopen (fileName,"w");
    if(punteroFile!=NULL)
    {
        for(i=0; i<listaEmpleados->len(listaEmpleados); i++)
        {
            auxEmpleados = al_get(listaEmpleados,i);

            retorno=fprintf(punteroFile,"%d,%s,%d,%.2f\n",auxEmpleados->id,auxEmpleados->nombre,auxEmpleados->horasTrabajo,auxEmpleados->sueldo);
        }
    }
    fclose(punteroFile);
    return retorno;
}

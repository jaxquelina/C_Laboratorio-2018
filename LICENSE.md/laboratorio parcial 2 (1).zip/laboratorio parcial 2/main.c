#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arraylist.h"
#include "validaciones.h"
#include "funciones.h"

int main()
{
    system("color F0");
    ArrayList* listaEmpleados=al_newArrayList();
    char seguir='s';
    int opcion=0;

      while(seguir=='s')
    {
        printf("Bienvenido al programa para administrar Empleados: :) \n");
        printf("1- Cargar Empleados\n");
        printf("2- Generar Lista\n");
        printf("3- Salir\n");

        printf("Ingrese una opcion para comenzar: ");
        scanf("%d",&opcion);

        switch(opcion)
        {
        case 1:
            {
             system("cls");
             printf("[ LISTADO DE EMPLEADOS \n ]");
             parser_parseEmpleados("data.csv",listaEmpleados);
             }
             system("pause");
             system("cls");
             break;



        case 2:
        {
        system("cls");
        printf("[CALCULANDO SUELDO DE EMPLEADOS] \n");
        al_map(listaEmpleados,calcularLosSueldos);

        if(generarArchivoSueldos("sueldos.csv",listaEmpleados)!=1)
        {
            printf("Archivo generado correctamente\n");
        }
        else
        {
            printf("Error generando archivo\n");

        }
        }
         system("pause");
         system("cls");
         break;

        case 3:
            {
            seguir = 'n';
            break;
        default:
            printf("opcion invalida");
            system("cls");
            break;

         }
    }
    }
    return 0;
}

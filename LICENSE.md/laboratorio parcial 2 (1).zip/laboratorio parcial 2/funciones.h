typedef struct{
    int id;
    char nombre[51];
    int horasTrabajo;
    float sueldo;
}eEmpleado;



/** \brief Esta funcion se encargara de generar memoria de forma dinamica para la estructura eEmpleado
 *
 * \return eEmpleado*
 *
 */
eEmpleado* new_Empleado();

/** \brief Esta funcion se encargara de mostrar a un empleado con su ID , su NOMBRE y sus respectivas horas de trabajo.
 *
 * \param auxEmpleado eEmpleado*
 * \return retornara 0 en caso de que se pueda mostrar correctamente y -1 en caso de generarse error.
 *
 */
int mostrar_Empleado(eEmpleado* auxEmpleado);

/** \brief Esta funcion crea un nuevo elementos empleado con valores especificados en los parametros
 *
 * \param id int , id del empleado
 * \param char nombre , nombre del empleado
 * \param int horas de trabajao , seran las horas de trabajo trabajadas por los trabajadores
 * \return
 *
 */
eEmpleado* empleado_Parametros(int id, char* nombre,int horasTrabajo);

/** \brief La funcion parser me permitira cargar el archivo con los datos de los respectivos empleados.
 *
 * \param fileName char*
 * \param listaEmpleados ArrayList*
 * \return int
 *
 */
int  parser_parseEmpleados(char* fileName, ArrayList* listaEmpleados);


/** \brief Esta funcion me permitira saber el sueldo que tendra cada empleado segun las horas laborales trabajadas.
 *
 * \param
 * \param
 * \return
 *
 */

void calcularLosSueldos(void* punteroAux);

/** \brief Esta funcion generara un nuevo archivo con los datos cargados de los sueldos de los empleados.
 *
 * \param fileName char*
 * \param listaEmpleados ArrayList*
 * \return int
 *
 */
int generarArchivoSueldos(char* fileName,ArrayList* listaEmpleados);



#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "ArrayList.h"
#include "destinatario.h"
#include "parcial2.h"

int parserDestinatario(FILE* pFile, ArrayList* pArrayListDestinatario,char dire[])
{
    int retorno=0;
    char auxName[100], auxMail[200];
    eDestinatario* desti;
    eDestinatario* aux;

    pFile=fopen(dire,"r");
    if(pFile!=NULL)
    {
        while(!feof(pFile))
        {
            fscanf(pFile,"%[^,],%[^\n]\n",auxName,auxMail);
            aux=desti_new();
            if(aux!=NULL)
            {

                desti=aux;
                setterName(desti,auxName);
                setterMail(desti,auxMail);
                pArrayListDestinatario->add(pArrayListDestinatario,desti);

            }
            else
            {
                printf("\nNo hay mas espacio\n");
            }
            retorno=1;
        }
    }
    fclose(pFile);
    return retorno;
}




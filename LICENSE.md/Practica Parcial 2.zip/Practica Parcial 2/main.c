#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "ArrayList.h"
#include "destinatario.h"
#include "parcial2.h"

int main()
{
    char seguir='s';
    int opcion=0;
    int aux;
    ArrayList* destinatarios;
    ArrayList* blackList;
    ArrayList* listaDepurada;
    FILE* archi;
    while(seguir=='s')
    {
        printf("1- Cargar destinatarios\n");
        printf("2- Cargar Lista Negra\n");
        printf("3- Depurar\n");
        printf("4- Listar\n");
        printf("5- Salir\n");

        scanf("%d",&opcion);

        switch(opcion)
        {
        case 1:
            destinatarios=al_newArrayList();
            if(destinatarios!=NULL)
            {
                cargar("\nIngrese ruta del archivo destinatarios\n",destinatarios,archi);
            }

            break;
        case 2:
            blackList=al_newArrayList();
            if(blackList!=NULL)
            {
                cargar("\ningrese ruta del archivo blacklist\n",blackList,archi);
            }
            system("pause");
            break;
        case 3:
            listaDepurada=al_newArrayList();
            if(listaDepurada!=NULL)
            {
                aux=depurar(destinatarios,blackList,listaDepurada);
                if(aux==0)
                {
                    printf("\nno se pudo\n");
                }
                else
                {
                    mostrarMuchos(listaDepurada);
                }
            }
            system("pause");
            system("cls");
            break;
        case 4:
            mostrarMuchos(destinatarios);
            break;

        case 5:
            seguir = 'n';
            break;
        default:
            printf("opcion invalida");
            system("cls");
            break;

        }
    }
    return 0;
}
